import cv2
from PySide6.QtWidgets import QLabel, QVBoxLayout, QPushButton
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt
from .camera_thread import CameraThread


class CameraController:
    def __init__(self, parent_widget, cam_index=0):
        self.cam_index = cam_index
        self.parent = parent_widget

        self.latest_frame = None
        self.thread = None

        # ===== UI =====
        self.video_label = QLabel("Camera not connected")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("background:black;color:white;")

        self.btn_toggle = QPushButton("Camera on")

        layout = QVBoxLayout(self.parent)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.video_label)
        layout.addWidget(self.btn_toggle)

        # ===== 事件绑定 =====
        self.btn_toggle.clicked.connect(self.toggle_camera)

    # ---------- 打开 / 关闭 ----------
    def toggle_camera(self):
        # ===== 打开 =====
        if self.thread is None:
            self.thread = CameraThread(self.cam_index)   # ⭐ 必须创建线程

            self.thread.frame_ready.connect(self.on_frame)
            self.thread.start()

            self.btn_toggle.setText("Camera off")

        # ===== 关闭 =====
        else:
            self.thread.stop()
            self.thread.wait()   # ⭐ 等线程真正结束（很重要）
            self.thread = None

            self.video_label.setText("Camera not connected")
            self.btn_toggle.setText("Camera on")

    # ---------- 接收帧 ----------
    def on_frame(self, image):
        self.latest_frame = image

    # ---------- UI刷新（主线程定时调用） ----------
    def update_ui(self):
        if self.latest_frame is None:
            return

        frame = self.latest_frame
        self.latest_frame = None  # ⭐ 防止堆积

        self.video_label.setPixmap(QPixmap.fromImage(frame))