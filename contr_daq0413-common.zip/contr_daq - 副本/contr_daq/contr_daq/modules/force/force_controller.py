# modules/force/force_controller.py
import numpy as np
from modules.force.force_thread import ForceThread
from modules.force.force_plot import ForcePlot
from modules.force.force_balance_plot import ForceBalancePlot
from utils.log import log


class ForceController:
    def __init__(self, ui):
        self.ui = ui

        self.running = False
        self.latest_force = 0.0
        self.latest_vals = None

        # ⭐新增：是否完成归零（关键）
        self.zero_done = False

        self.zero_offset = np.zeros(4)
        self.plot = ForcePlot(self.ui.forcePlotWidget, time_window=10.0)
        self.thread = None
        self.zero_buffer = []

        self.ui.forceStartButton.clicked.connect(self.toggle)
        self.ui.forceZeroButton.clicked.connect(self.zero)

        # ================= 按钮样式 =================
        # ▶ Start按钮（可保持绿色）
        self.ui.forceStartButton.setCheckable(True)
        self.ui.forceStartButton.setStyleSheet("""
            QPushButton {
                background-color: lightgray;
            }
            QPushButton:checked {
                background-color: green;
            }
            """)

        # ▶ Zero按钮（短暂绿色）
        self.ui.forceZeroButton.setStyleSheet("""
            QPushButton {
                background-color: lightgray;
            }
            QPushButton:pressed {
                background-color: green;
            }
            """)

    # =========================
    def toggle(self):
        if self.thread and self.thread.isRunning():
            self.stop()
        else:
            self.start()

    # =========================
    def start(self):
        self.plot.clear()
        self.zero_buffer.clear()

        # ⭐关键：重新开始必须重新归零
        self.zero_done = False

        self.thread = ForceThread(port="COM8", baudrate=9600)
        self.thread.data_ready.connect(self.on_data)
        self.thread.started_ok.connect(self.on_started)

        self.thread.start()

    # =========================
    def stop(self):
        if self.thread:
            self.thread.stop()
            self.thread = None

        self.running = False

        # ⭐关键：停止后取消检测资格
        self.zero_done = False

        self.ui.forceStartButton.setText("Start")

    # =========================
    def zero(self):
        if len(self.zero_buffer) < 100:
            print("[Force] 数据不足，无法归零")
            return

        # ⭐用原始数据算零点
        self.zero_offset = np.mean(self.zero_buffer[-100:], axis=0)

        # ⭐关键：归零完成 → 才允许检测
        self.zero_done = True

        print("[Force] 归零完成（开始监测）")

    # =========================
    def on_started(self, ok):
        if ok:
            self.running = True
            self.ui.forceStartButton.setText("Stop")
        else:
            self.running = False
            self.thread = None
            self.ui.forceStartButton.setText("Start")
            print("[Force] 启动失败")

    # =========================
    def on_data(self, total_force, vals):
        vals = np.array(vals)

        # ⭐存原始数据（用于归零）
        self.zero_buffer.append(vals)
        if len(self.zero_buffer) > 300:
            self.zero_buffer.pop(0)

        # ⭐零点修正
        vals = vals - self.zero_offset

        self.latest_vals = vals
        self.latest_force = float(np.sum(vals))

    # =========================
    def update_ui(self):
        if not self.running or self.latest_vals is None:
            return

        # ===== 总力 =====
        self.ui.totalForceLabel.setText(
            f"Total Force: {self.latest_force:.2f}"
        )

        # ===== 四通道 =====
        self.ui.Force1_Label.setText(f"P1: {self.latest_vals[0]:.2f}")
        self.ui.Force2_Label.setText(f"P2: {self.latest_vals[1]:.2f}")
        self.ui.Force3_Label.setText(f"P3: {self.latest_vals[2]:.2f}")
        self.ui.Force4_Label.setText(f"P4: {self.latest_vals[3]:.2f}")

        # ===== 曲线 =====
        self.plot.add_point(self.latest_force)