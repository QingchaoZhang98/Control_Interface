# modules/motion/motion_controller.py

from modules.motion.net_amc4xer import NetAMC4XER
from utils.log import log
from pathlib import Path
from modules.motion.MotionLoopThread import MotionLoopThread


class MotionController:
    AXIS_MAP = {
        "X": 1,
        "Y": 0,
        "Z": 3,
        "R": 2,
    }

    BASE_DIR = Path(__file__).resolve().parents[2]
    dll_path = BASE_DIR / "dll" / "NET_AMC4XER.dll"

    def __init__(self, ui):
        self.ui = ui
        self.loop_thread = None

        self.motion = NetAMC4XER(
            dll_path=str(self.dll_path),
            dest_ip="192.168.1.30"
        )
        # ================= 按钮列表 =================
        self.buttons = [
            self.ui.xPosButton,
            self.ui.xNegButton,
            self.ui.yPosButton,
            self.ui.yNegButton,
            self.ui.zPosButton,
            self.ui.zNegButton,
            self.ui.RPosButton,
            self.ui.RNegButton
        ]

        # ================= 按钮样式 =================
        for btn in self.buttons:
            btn.setStyleSheet("""
            QPushButton {
                background-color: lightgray;
            }
            QPushButton:pressed {
                background-color: green;
            }
            """)

        # ===== 绑定按钮 =====
        self.ui.xPosButton.clicked.connect(lambda: self.move("X", +1))
        self.ui.xNegButton.clicked.connect(lambda: self.move("X", -1))
        self.ui.yPosButton.clicked.connect(lambda: self.move("Y", +1))
        self.ui.yNegButton.clicked.connect(lambda: self.move("Y", -1))
        self.ui.zPosButton.clicked.connect(lambda: self.move("Z", +1))
        self.ui.zNegButton.clicked.connect(lambda: self.move("Z", -1))
        self.ui.RPosButton.clicked.connect(lambda: self.move("R", +1))
        self.ui.RNegButton.clicked.connect(lambda: self.move("R", -1))

        # ❌ 删除这一行（非常重要）
        # self.ui.Emergency_Stop.clicked.connect(self.emergency_stop)

    # =============================
    # 安全检查（核心新增 ⭐）
    # =============================
    def is_emergency(self):
        if hasattr(self.ui, "main_window"):
            return self.ui.main_window.emergency_triggered
        return False

    # =============================
    # 点动
    # =============================
    def move(self, axis_name: str, direction: int):
        # ⭐急停锁
        if self.is_emergency():
            print("⚠️ 急停状态，禁止运动")
            return

        axis = self.AXIS_MAP[axis_name]
        distance_mm = self.ui.distanceSpinBox.value()

        if axis_name == "Z":
            length_pulse = self.mm_to_pulse_Z(distance_mm)
            speed = 1
        else:
            length_pulse = self.mm_to_pulse_X_Y_U(distance_mm)
            speed = self.ui.Speed_Setting_val.value()

        log(f"[Motion] {axis_name} {'+' if direction > 0 else '-'} {distance_mm} mm")

        self.motion.enable_axis(axis)
        self.motion.move_relative(
            axis,
            0 if direction > 0 else 1,
            length_pulse,
            speed
        )

    # =============================
    def move_single(self, axis_name, direction, distance_mm):
        if self.is_emergency():
            print("⚠️ 急停状态，禁止运动")
            return

        axis = self.AXIS_MAP[axis_name]

        if axis_name == "Z":
            length_pulse = self.mm_to_pulse_Z(distance_mm)
            speed = 1
        else:
            length_pulse = self.mm_to_pulse_X_Y_U(distance_mm)
            speed = self.ui.Speed_Setting_val.value()

        self.motion.enable_axis(axis)
        self.motion.move_relative(
            axis,
            0 if direction > 0 else 1,
            length_pulse,
            speed
        )

    # =============================
    def start_loop(self, direction):
        if self.is_emergency():
            print("⚠️ 急停状态，禁止循环运动")
            return

        if self.loop_thread and self.loop_thread.isRunning():
            return

        axis_name = self.ui.Axis_choice.currentText()
        times = self.ui.Circle_times.value()
        distance = self.ui.distanceSpinBox_2.value()
        gap = self.ui.Gap_time.value()

        self.loop_thread = MotionLoopThread(
            self,
            axis_name,
            direction,
            distance,
            times,
            gap
        )

        self.loop_thread.finished.connect(self.on_loop_finished)

        self.lock_ui(True)
        self.loop_thread.start()

    # =============================
    def on_loop_finished(self):
        self.lock_ui(False)
        print("[Motion] 循环完成")

    # =============================
    def emergency_stop(self):
        print("[Motion] 急停触发")

        if self.loop_thread:
            self.loop_thread.stop()
            self.loop_thread = None

        try:
            for axis in self.AXIS_MAP.values():
                self.motion.stop_axis(axis)
        except Exception as e:
            print("急停失败:", e)

        self.lock_ui(False)

    # =============================
    def lock_ui(self, locked: bool):
        self.ui.Axis_choice.setEnabled(not locked)
        self.ui.Circle_times.setEnabled(not locked)
        self.ui.distanceSpinBox_2.setEnabled(not locked)
        self.ui.Gap_time.setEnabled(not locked)

        self.ui.Forward_circle.setEnabled(not locked)
        self.ui.Backward_circle.setEnabled(not locked)

        self.ui.Emergency_Stop.setEnabled(True)

    # =============================
    def mm_to_pulse_Z(self, mm: float) -> int:
        return int(mm * 10959)

    def mm_to_pulse_X_Y_U(self, mm: float) -> int:
        return int(mm * 2000)