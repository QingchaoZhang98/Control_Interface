from PySide6.QtWidgets import QApplication
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import QTimer, Qt

from modules.camera.camera_controller import CameraController
from modules.motion.motion_controller import MotionController
from modules.force.force_controller import ForceController
from utils.log import bind_log_widget


class MainWindow:
    def __init__(self):
        super().__init__()
        self.ui = QUiLoader().load('daq_ui.ui')

        self.ui.setWindowTitle("BFE_Control_Interface")

        bind_log_widget(self.ui.logTextEdit)

        # ===== 模块 =====
        self.camera_controller_1 = CameraController(self.ui.Camera1, cam_index=0)
        self.motion_controller = MotionController(self.ui)
        self.force_controller = ForceController(self.ui)

        # ⭐让子模块访问主控
        self.ui.main_window = self

        # ===== 状态 =====
        self.emergency_triggered = False
        self.over_limit_count = 0

        # ===== 默认阈值 =====
        self.ui.LimitspinBox.setValue(100)

        # ⭐接管急停按钮
        self.ui.Emergency_Stop.clicked.connect(self.handle_emergency_button)

        # ===== 定时器 =====
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_all_ui)
        self.timer.start(30)

        self.ui.showMaximized()

    # =========================
    def update_all_ui(self):
        self.camera_controller_1.update_ui()
        self.force_controller.update_ui()

        self.check_force_limit()

    # =========================
    def handle_emergency_button(self):
        if not self.emergency_triggered:
            self.trigger_emergency("手动急停")
        else:
            self.reset_system()

    # =========================
    def trigger_emergency(self, reason=""):
        if self.emergency_triggered:
            return

        print(f"🚨 急停: {reason}")

        self.motion_controller.emergency_stop()

        self.emergency_triggered = True

        # 按钮变RESET
        self.ui.Emergency_Stop.setText("RESET")
        self.ui.Emergency_Stop.setStyleSheet(
            "background-color: orange; font-weight: bold;"
        )

    # =========================
    def reset_system(self):
        print("✅ 系统复位")

        self.emergency_triggered = False
        self.over_limit_count = 0

        self.ui.Emergency_Stop.setText("E-stop")
        self.ui.Emergency_Stop.setStyleSheet(
            "background-color: red; color: white;"
        )

    # =========================
    def get_force_limit(self):
        return float(self.ui.LimitspinBox.value())

    # =========================
    def check_force_limit(self):
        fc = self.force_controller

        # ⭐必须：Start + Zero之后
        if not fc.running:
            return
        if not fc.zero_done:
            return

        if self.emergency_triggered:
            return

        force = fc.latest_force
        limit = self.get_force_limit()

        if force is None:
            return

        # 抗抖
        if force >= limit:
            self.over_limit_count += 1
        else:
            self.over_limit_count = 0

        if self.over_limit_count >= 3:
            self.trigger_emergency(f"压力超限 {force:.2f} ≥ {limit}")

    # =========================
    def closeEvent(self, event):
        if self.camera_controller_1.thread:
            self.camera_controller_1.thread.stop()

        if self.force_controller.thread:
            self.force_controller.stop()

        event.accept()


app = QApplication()
Daq = MainWindow()
app.exec()