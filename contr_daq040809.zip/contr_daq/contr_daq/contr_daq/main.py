import queue
from collections import deque

import nidaqmx
import nidaqmx.system

from PySide6.QtWidgets import (
    QApplication, QWidget
)
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import (
    QTimer
)

from PySide6.QtCore import Qt

import pyqtgraph as pg

from modules.camera.camera_controller import CameraController
from modules.daq.daq_controller import DaqController
from modules.daq.ao_controller import AOController
import logging
from utils.log import bind_log_widget
from modules.daq.iv_controller import IVController
from modules.daq.daq_plot import DaqPlot
from modules.motion.motion_controller import MotionController
from modules.force.force_controller import ForceController
from modules.ui.led_indicator import LedIndicatorManager


class MainWindow:
    AI_CHANNELS = [f"ai{i}" for i in range(8)]

    def __init__(self):
        super().__init__()
        self.ui = QUiLoader().load('daq_ui.ui')

        self.ui.setWindowFlag(Qt.Window, True)
        self.ui.setWindowFlag(Qt.WindowMinimizeButtonHint, True)
        self.ui.setWindowFlag(Qt.WindowMaximizeButtonHint, True)
        self.ui.setWindowFlag(Qt.WindowCloseButtonHint, True)

        self.ui.setWindowTitle("BFE_Control_Interface")

        # ===== 模块初始化 =====
        self.camera_controller_1 = CameraController(self.ui.Camera1, cam_index=0)
        self.motion_controller = MotionController(self.ui)
        self.force_controller = ForceController(self.ui)

        # ⭐ 急停状态标志
        self.emergency_triggered = False

        # ⭐ 默认压力阈值 = 100
        self.ui.LimitspinBox.setValue(101)

        # ===== 定时器 =====
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_all_ui)
        self.timer.start(30)  # 30ms刷新

    # =========================
    # UI刷新主循环
    # =========================
    def update_all_ui(self):
        if hasattr(self, "camera_controller_1"):
            self.camera_controller_1.update_ui()

        if hasattr(self, "force_controller"):
            self.force_controller.update_ui()

            # ⭐ 重新点击Start → 自动解除急停
            if self.force_controller.running:
                self.emergency_triggered = False

        # ⭐ 压力安全检测
        self.check_force_limit()

    # =========================
    # 获取压力阈值（SpinBox）
    # =========================
    def get_force_limit(self):
        try:
            return float(self.ui.LimitspinBox.value())
        except:
            return None

    # =========================
    # 核心：压力急停逻辑
    # =========================
    def check_force_limit(self):
        # ⭐ 未点击Start → 不判断
        if not self.force_controller.running:
            return

        # ⭐ 已急停 → 不重复触发
        if self.emergency_triggered:
            return

        limit = self.get_force_limit()
        if limit is None:
            return

        current_force = self.force_controller.latest_force

        if current_force is None:
            return

        if current_force >= limit:
            print(f"🚨 力超限！当前: {current_force:.2f} ≥ 阈值: {limit}")

            # ⭐ 执行急停
            self.motion_controller.emergency_stop()

            # ⭐ 锁定状态
            self.emergency_triggered = True

    # =========================
    # 关闭程序
    # =========================
    def closeEvent(self, event):
        if self.camera_controller_1.thread:
            self.camera_controller_1.thread.stop()
        event.accept()


# =========================
# 主程序入口
# =========================
app = QApplication()
Daq = MainWindow()
Daq.ui.show()
app.exec()